package in.conceptarchitect.finance;

public class ATM {

	Bank B=new Bank(null, 10);
	BankAccount BA=new BankAccount(1, null, null, 10);
	
	public void changePassword(String oldpassword,String newpassword) {
		BA.changePassword(oldpassword, newpassword);		
	}
	
	public void deposit(int accountNumber,double amount) {
		B.deposit(accountNumber, amount);
			
	}
	
	public void withdraw(int accountNumber,double amount,String password) {
		B.withdraw(accountNumber, amount, password);
	}
	
	
}
